const express = require('express');

exports.handler = async function handler(event, context) {
  console.log(context.requestId, event.httpMethod, event.path, JSON.stringify(event.queryStringParameters), JSON.stringify(event.headers));

  if (event.httpMethod === "GET" && event.path === "/weather") {
    const city = event.queryStringParameters["city"];
    if (!city) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          error: "missing city",
        }),
      };
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        city,
        weather: "大雨",
        temperature: 25,
        humidity: 95,
      }),
    };
  }
  if (event.httpMethod === "POST" && event.path === "/precipitation") {
    const body = JSON.parse(event.body);
    const city = body["city"];
    if (!city) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          error: "missing city",
        }),
      };
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        city,
        humidity: 95,
        probability: 100,
      }),
    };
  }
  if (event.httpMethod === "GET" && event.path === "/warnings") {
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        warnings: [
          {
            name: "台风蓝色预警",
            city: "上海",
          },
          {
            name: "暴雨黄色预警",
            city: "上海",
          },
        ],
      }),
    };
  }

  if (event.httpMethod === "GET" && event.path === "/") {
    return {
      statusCode: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
      body: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>火山天气</title>
  </head>
  <body>
    <h1>火山天气</h1>
    <h2>Swagger</h2>
    <div style="font-family: monospace; white-space: pre">
{
  "swagger": "2.0",
  "info": {
    "title": "volc-weather",
    "version": "0.0.1"
  },
  "paths": {
    "/weather": {
      "get": {
        "operationId": "weather",
        "summary": "查看天气情况。",
        "parameters": [
          {
            "name": "city",
            "description": "城市。",
            "type": "string",
            "in": "query",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "天气情况。",
            "schema": {
              "type": "object",
              "properties": {
                "city": {
                  "description": "城市。",
                  "type": "string"
                },
                "weather": {
                  "description": "天气。",
                  "type": "string"
                },
                "temperature": {
                  "description": "温度，单位摄氏度。",
                  "type": "number"
                },
                "humidity": {
                  "description": "湿度，单位百分比。",
                  "type": "number"
                }
              }
            }
          }
        }
      }
    },
    "/precipitation": {
      "post": {
        "operationId": "precipitation",
        "summary": "查看降水情况。",
        "consumes": ["application/json"],
        "parameters": [
          {
            "name": "Body",
            "in": "body",
            "schema": {
              "type": "object",
              "properties": {
                "city": {
                  "description": "城市。",
                  "type": "string"
                }
              }
            }
          }
        ],
        "responses": {
          "200": {
            "description": "降水情况。",
            "schema": {
              "type": "object",
              "properties": {
                "city": {
                  "description": "城市。",
                  "type": "string"
                },
                "humidity": {
                  "description": "湿度，单位百分比。",
                  "type": "number"
                },
                "probability": {
                  "description": "降水概率，单位百分比。",
                  "type": "number"
                }
              }
            }
          }
        }
      }
    },
    "/warnings": {
      "get": {
        "operationId": "warnings",
        "summary": "查看气象预警。",
        "responses": {
          "200": {
            "description": "气象预警。",
            "schema": {
              "type": "object",
              "properties": {
                "warnings": {
                  "description": "预警。",
                  "type": "array",
                  "items": {
                    "type": "object",
                    "properties": {
                      "name": {
                        "description": "预警名称。",
                        "type": "string"
                      },
                      "city": {
                        "description": "预警城市。",
                        "type": "string"
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
    </div>
  </body>
</html>`,
    };
  }

  return {
    statusCode: 404,
    headers: { "Content-Type": "text/plain; charset=utf-8" },
    body: "Not Found",
  };
};

// Web 服务器功能
if (require.main === module) {
  const express = require('express');

  const app = express();
  const port = process.env.PORT || 8080;

  app.use(express.json());

  // 通用路由处理器
  app.use(async (req, res) => {
    const event = {
      httpMethod: req.method,
      path: req.path,
      queryStringParameters: req.query,
      headers: req.headers,
      body: req.method === 'POST' ? JSON.stringify(req.body) : null
    };

    const context = {
      requestId: Date.now().toString()
    };

    try {
      const result = await exports.handler(event, context);
      res.status(result.statusCode).set(result.headers).send(result.body);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  const server = app.listen(port, () => {
    console.log(`Web service running at http://localhost:${port}`);
    console.log('Press Ctrl+C to stop the service');
  });

  // 优雅关闭
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    server.close(() => {
      process.exit(0);
    });
  });

  process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully');
    server.close(() => {
      process.exit(0);
    });
  });

  // 保持进程运行
  setInterval(() => {}, 1000);
}
