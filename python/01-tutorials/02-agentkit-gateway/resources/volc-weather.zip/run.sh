#!/bin/bash

# Web 服务启动脚本 - volc-weather
set -e

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "Starting volc-weather web service..."

# 检查 Node.js 是否安装
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed"
    exit 1
fi

# 设置环境变量
export NODE_ENV=${NODE_ENV:-production}
export PORT=${PORT:-8000}
export HOST=${HOST:-0.0.0.0}

# 启动 web 服务（阻塞执行）
echo "Starting web service at http://$HOST:$PORT"
exec node index.js
