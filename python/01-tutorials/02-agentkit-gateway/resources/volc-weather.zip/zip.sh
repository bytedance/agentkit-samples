#!/bin/bash
set -ex

ZIP_NAME="$(basename "$PWD").zip"

rm -f "$ZIP_NAME"

zip -r "$ZIP_NAME" . \
  -x "node_modules/.cache/*" \
  -x "**/.DS_Store" \
  -x "**/npm-debug.log" \
  -x "**/yarn-error.log" \
  -x "**/.git/*" \

echo "Created $ZIP_NAME"