import os
import time
import logging
from pydantic import BaseModel

__all__ = ["Result"]

### 日志配置
log_dir = "/tmp/openclaw/replicator"
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    filename=f'{log_dir}/info.{time.strftime("%Y%m%d", time.localtime())}.log',
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

### 结果模型
class Result(BaseModel):
    code: str
    message: str
    data: object = None