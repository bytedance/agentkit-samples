#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import click
import hashlib
import json
import os
import sys
import time
import hmac
import logging
import jsonpath
import requests
import zlib
from pydantic import BaseModel
from urllib.parse import urlencode, urlparse
from typing import List, TypedDict, Dict
from dotenv import load_dotenv
from abc import ABC, abstractmethod

from .base import Result
load_dotenv()

# ─── 类型定义 ──────────────────────────────────────────

class RangeDict(TypedDict):
    Start: int
    End: int

class UploadStateResult(TypedDict):
    SkipDataComplete: bool
    PartSize: int
    Ranges: List[RangeDict]

class Matriel(BaseModel):
    id: str
    type: str
    url: str
    width: int
    height: int

class ImageMatriel(Matriel):
    pass

class VideoMatriel(Matriel):
    duration: float


# ─── 配置管理 ──────────────────────────────────────────

class AppConfig:
    """全局配置管理"""
    ACCESS_KEY_ID = os.getenv("ACCESS_KEY_ID") or ""
    SECRET_ACCESS_KEY = os.getenv("SECRET_ACCESS_KEY") or ""
    ARKCLAW_TOKEN = os.getenv("ARK_SKILL_API_KEY") or ""

    DEFAULT_HOST = os.getenv("ARK_SKILL_API_BASE") or ""
    DEFAULT_ICP_HOST = "https://icp.volcengineapi.com"

    REGION = "cn-north"
    VERSION = "2022-02-01"

    SERVICE_MUSE = "iccloud_muse"
    SERVICE_IAM = "ic_iam"

    POLL_MAX_ATTEMPTS = 60
    POLL_INTERVAL = 5

    IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "gif", "bmp", "webp", "tiff", "tif"}
    VIDEO_EXTENSIONS = {"mp4", "avi", "mov", "wmv", "flv", "mkv", "webm", "m4v", "3gp"}


# ─── 工具类 ────────────────────────────────────────────

class HashUtils:
    """哈希计算工具"""
    @staticmethod
    def hmac_sha256(key: bytes, content: str) -> bytes:
        h = hmac.new(key, content.encode("utf-8"), hashlib.sha256)
        return h.digest()

    @staticmethod
    def hash_sha256(data: bytes) -> bytes:
        h = hashlib.sha256()
        h.update(data)
        return h.digest()

    @staticmethod
    def file_hash(file_path: str):
        file_md5_obj = hashlib.md5()
        file_crc32 = 0
        file_size = 0
        with open(file_path, "rb") as f:
            while chunk := f.read(8192 * 1024):
                file_md5_obj.update(chunk)
                file_crc32 = zlib.crc32(chunk, file_crc32)
                file_size += len(chunk)
        return file_md5_obj.hexdigest(), file_crc32 & 0xFFFFFFFF, file_size


# ─── 鉴权策略模式 ──────────────────────────────────────

class AuthStrategy(ABC):
    @abstractmethod
    def build_headers(self, service: str, host: str, query_string: str, payload_hash: str, is_binary: bool) -> Dict[str, str]:
        pass

    @abstractmethod
    def build_url(self, host: str, action: str, extra_query: dict) -> str:
        pass


class ArkClawAuthStrategy(AuthStrategy):
    def __init__(self, token: str):
        self.token = token

    def build_headers(self, service: str, host: str, query_string: str, payload_hash: str, is_binary: bool) -> Dict[str, str]:
        return {
            "ServiceName": service,
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/octet-stream" if is_binary else "application/json"
        }

    def build_url(self, host: str, action: str, extra_query: dict) -> str:
        url = f"{host}/?Action={action}&Version={AppConfig.VERSION}"
        if extra_query:
            url += "&" + urlencode(extra_query)
        return url


class AkSkAuthStrategy(AuthStrategy):
    def __init__(self, ak: str, sk: str):
        self.ak = ak
        self.sk = sk

    def build_headers(self, service: str, host: str, query_string: str, payload_hash: str, is_binary: bool) -> Dict[str, str]:
        date = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime(time.time()))
        auth_date = date[:8]

        content_type = "application/octet-stream" if is_binary else "application/json"
        signed_headers = ["host", "x-date", "x-content-sha256", "content-type"]
        
        parsed_url = urlparse(host)
        host_name = parsed_url.netloc

        header_list = [
            f"host:{host_name}",
            f"x-date:{date}",
            f"x-content-sha256:{payload_hash}",
            f"content-type:{content_type}"
        ]
        header_string = "\n".join(header_list)

        canonical_string = "\n".join(["POST", "/", query_string, f"{header_string}\n", ";".join(signed_headers), payload_hash])
        hashed_canonical_string = HashUtils.hash_sha256(canonical_string.encode("utf-8")).hex()
        
        credential_scope = f"{auth_date}/{AppConfig.REGION}/{service}/request"
        sign_string = "\n".join(["HMAC-SHA256", date, credential_scope, hashed_canonical_string])
        
        k_date = HashUtils.hmac_sha256(self.sk.encode("utf-8"), auth_date)
        k_region = HashUtils.hmac_sha256(k_date, AppConfig.REGION)
        k_service = HashUtils.hmac_sha256(k_region, service)
        signed_key = HashUtils.hmac_sha256(k_service, "request")
        
        signature = HashUtils.hmac_sha256(signed_key, sign_string).hex()
        authorization = (f"HMAC-SHA256 Credential={self.ak}/{credential_scope},"
                         f" SignedHeaders={';'.join(signed_headers)},"
                         f" Signature={signature}")

        return {
            "X-Date": date,
            "X-Content-Sha256": payload_hash,
            "Content-Type": content_type,
            "Authorization": authorization
        }

    def build_url(self, host: str, action: str, extra_query: dict) -> str:
        queries = extra_query.copy()
        queries["Action"] = action
        queries["Version"] = AppConfig.VERSION
        query_string = urlencode(sorted(queries.items())).replace("+", "%20")
        return f"{host}?{query_string}"


# ─── API 客户端 ────────────────────────────────────────

class ApiClient:
    """处理与后端的 HTTP 交互"""
    def __init__(self, host: str, strategy: AuthStrategy):
        self.host = host
        self.strategy = strategy

    def _check_resp(self, resp: dict, action: str):
        meta = resp.get("ResponseMetadata", {})
        error_obj = meta.get("Error")
        if error_obj:
            code = error_obj.get("Code") or error_obj.get("CodeN")
            msg = error_obj.get("Message", "")
            print(f"❌ {action} 失败: code={code}, msg={msg}")
            sys.exit(1)
            
        code = meta.get("Code")
        if code is not None and str(code) not in ("0", "Success", "200"):
            msg = meta.get("Message") or ""
            print(f"❌ {action} 失败: code={code}, msg={msg}")
            sys.exit(1)

    def request(self, action: str, service: str, body: dict = None, extra_query: dict = None) -> dict: # type: ignore
        extra_query = extra_query or {}
        body_bytes = json.dumps(body or {}, ensure_ascii=False).encode()
        payload_hash = HashUtils.hash_sha256(body_bytes).hex()

        url = self.strategy.build_url(self.host, action, extra_query)
        query_string = urlparse(url).query
        headers = self.strategy.build_headers(service, self.host, query_string, payload_hash, is_binary=False)

        logging.info(f"[http] <<< {headers} {json.dumps(body or {}, ensure_ascii=False)}")
        resp = requests.post(url, data=body_bytes, headers=headers, timeout=30)
        logging.info(f"[http] <<< {resp.headers} {resp.text}")
        
        try:
            result = resp.json()
        except Exception:
            print(f"json parse error, resp is {resp.text}")
            sys.exit(1)
            
        self._check_resp(result, action)
        return result

    def request_binary(self, action: str, service: str, extra_query: dict, data: bytes) -> dict:
        payload_hash = HashUtils.hash_sha256(data).hex()
        url = self.strategy.build_url(self.host, action, extra_query)
        query_string = urlparse(url).query
        headers = self.strategy.build_headers(service, self.host, query_string, payload_hash, is_binary=True)

        resp = requests.post(url, data=data, headers=headers, timeout=60)
        try:
            result = resp.json()
        except Exception:
            print(f"json parse error, resp is {resp.text}")
            sys.exit(1)
            
        self._check_resp(result, action)
        return result


# ─── 业务服务层 ────────────────────────────────────────

class IamService:
    def __init__(self, client: ApiClient):
        self.client = client

    def get_admin_user_id(self) -> int:
        result = self.client.request(action="ListUsers", service=AppConfig.SERVICE_IAM, body={"UserType": "All"})
        users = result.get("Result", {}).get("Users", [])
        if not users:
            print("❌ 未获取到任何用户信息")
            sys.exit(1)

        for user in users:
            if user.get("IsAdmin") and user.get("Id"):
                return user.get("Id")
        return users[0].get("Id")


class MuseService:
    def __init__(self, client: ApiClient):
        self.client = client

    def get_upload_state(self, file_md5: str, file_size: int, file_crc32: int, owner_id: int) -> UploadStateResult:
        body = {
            "Owner": {"Id": owner_id, "Type": "PERSON"},
            "Md5": file_md5, "Size": file_size,
            "Start": 0, "End": file_size - 1, "Crc": file_crc32
        }
        result = self.client.request(action="GetUploadState", service=AppConfig.SERVICE_MUSE, body=body)
        raw_state = result.get("Result", {})
        return {
            "SkipDataComplete": bool(raw_state.get("SkipDataComplete", False)),
            "PartSize": int(raw_state.get("PartSize", 0)),
            "Ranges": raw_state.get("Ranges", [])
        }

    def upload_part(self, owner_id: int, chunk: bytes, offset: int, part_size: int, chunk_md5: str) -> dict:
        query = {
            "Md5": chunk_md5, "Size": part_size, "Offset": offset,
            "OwnerId": owner_id, "OwnerType": "PERSON"
        }
        return self.client.request_binary("StreamUploadData", AppConfig.SERVICE_MUSE, query, chunk)

    def create_material(self, file_md5: str, file_size: int, file_name: str, file_ext: str,
                        skip_data_complete: bool, owner_id: int, owner_type: str,
                        title: str, category: str) -> str:
        body = {
            "Owner": {"Id": owner_id, "Type": "PERSON"},
            "StoreItem": {
                "Md5": file_md5, "Size": file_size, "SkipDataComplete": skip_data_complete,
                "Filename": file_name, "FileExtension": file_ext,
            },
            "CreateMaterialInfo": {
                "Visibility": 0, "Title": title, "MediaType": 1,
                "MediaFirstCategory": category, "Tags": [], "MediaExtension": file_ext,
            },
        }
        result = self.client.request(action="CreateMaterial", service=AppConfig.SERVICE_MUSE, body=body)
        return result.get("Result", {}).get("MediaId")

    def poll_media_info(self, media_id: str, owner_id: int, owner_type: str) -> dict:
        for _ in range(AppConfig.POLL_MAX_ATTEMPTS):
            result = self.client.request(
                action="GetMediaInfo", service=AppConfig.SERVICE_MUSE,
                body={"MediaIds": [media_id], "MediaType": 1},
            )
            media_infos = result.get("Result", {}).get("MediaInfos", [])
            if media_infos:
                media_info = media_infos[0]
                status = media_info.get("BasicInfo", {}).get("MediaStatus")
                if status >= 2:
                    return media_info
                if status in (1, 5):
                    print("❌ 处理失败")
                    sys.exit(1)
            time.sleep(AppConfig.POLL_INTERVAL)
        sys.exit(1)


# ─── 编排与格式化层 ────────────────────────────────────

class MaterialUploader:
    def __init__(self, client: ApiClient):
        self.iam = IamService(client)
        self.muse = MuseService(client)

    def stream_upload(self, file_path: str, file_md5: str, file_size: int, file_crc32: int,
                      owner_id: int, state: UploadStateResult) -> UploadStateResult:
        if state["SkipDataComplete"]:
            return state
        
        with open(file_path, "rb") as f:
            data = f.read()
        
        offset = 0
        for _ in range(1000):
            if state["SkipDataComplete"]: break
            part_size = state.get("PartSize", 0)
            
            if part_size == 0:
                chunk, chunk_size = data, file_size
            else:
                chunk_size = part_size if offset + part_size * 2 <= file_size else file_size - offset
                chunk = data[offset : offset + chunk_size]
            
            self.muse.upload_part(owner_id, chunk, offset, chunk_size, file_md5)
            offset += chunk_size
            state = self.muse.get_upload_state(file_md5, file_size, file_crc32, owner_id)
            
            if state["SkipDataComplete"] or not state["Ranges"] or offset >= file_size:
                return state
        return state


class MediaFormatter:
    @staticmethod
    def extract_url(media_info: dict) -> str:
        cat = media_info.get("BasicInfo", {}).get("MediaFirstCategory", "")
        if cat == "image":
            image_media = media_info.get("ImageMedia", {})
            if dl := image_media.get("DownloadUrl"): return dl
            for q in ["origin", "jpeg_1080p", "jpeg_480p"]:
                if url := image_media.get("TranscodeDownloadUrls", {}).get(q): return url
        elif cat in ("video", "audio"):
            media = media_info.get("VideoMedia" if cat == "video" else "AudioMedia", {})
            if dl := media.get("DownloadUrl"): return dl
            if play := media.get("PlayInfo", []): return play[0].get("Url", "")
        return ""

    @staticmethod
    def simplify(media_info: dict) -> dict:
        # 保持原逻辑的 simplify
        cat = media_info.get("BasicInfo", {}).get("MediaFirstCategory", "")
        if cat == "image":
            im = media_info.get("ImageMedia", {})
            if dl := im.get("DownloadUrl"): im["DownloadUrl"] = dl
            for q in ["origin", "jpeg_1080p", "jpeg_480p"]:
                if url := im.get("TranscodeDownloadUrls", {}).get(q):
                    im["TranscodeDownloadUrls"][q] = url
        elif cat in ("video", "audio"):
            vm = media_info.get("VideoMedia" if cat == "video" else "AudioMedia", {})
            if dl := vm.get("DownloadUrl"): vm["DownloadUrl"] = dl
            if play := vm.get("PlayInfo", []): play[0]["Url"] = play[0].get("Url")
        return media_info

    @staticmethod
    def format(media_info: dict) -> Matriel:
        if jsonpath.jsonpath(media_info, "$.ImageMedia"):
            m = ImageMatriel(id='', type="image", url="", height=0, width=0)
            if v := jsonpath.jsonpath(media_info, "$.BasicInfo.MediaId"): m.id = v[0]
            if v := jsonpath.jsonpath(media_info, "$.ImageMedia.DownloadUrl"): m.url = v[0]
            if v := jsonpath.jsonpath(media_info, "$.ImageMedia.Width"): m.width = v[0]
            if v := jsonpath.jsonpath(media_info, "$.ImageMedia.Height"): m.height = v[0]
            return m
        elif jsonpath.jsonpath(media_info, "$.VideoMedia"):
            m = VideoMatriel(id="", type="video", url="", height=0, width=0, duration=0)
            if v := jsonpath.jsonpath(media_info, "$.BasicInfo.MediaId"): m.id = v[0]
            if v := jsonpath.jsonpath(media_info, "$.VideoMedia.DownloadUrl"): m.url = v[0]
            if v := jsonpath.jsonpath(media_info, "$.VideoMedia.MediaMetaInfo.Width"): m.width = v[0]
            if v := jsonpath.jsonpath(media_info, "$.VideoMedia.MediaMetaInfo.Height"): m.height = v[0]
            if v := jsonpath.jsonpath(media_info, "$.VideoMedia.MediaMetaInfo.Duration"): m.duration = v[0] / 1000
            return m
        return Matriel(id="", type="", url="", height=0, width=0)


# ─── 主入口 ────────────────────────────────────────────

def _build_client() -> ApiClient:
    if AppConfig.ARKCLAW_TOKEN:
        strategy = ArkClawAuthStrategy(AppConfig.ARKCLAW_TOKEN)
        host = AppConfig.DEFAULT_HOST
        return ApiClient(host, strategy)
    if AppConfig.ACCESS_KEY_ID and AppConfig.SECRET_ACCESS_KEY:
        strategy = AkSkAuthStrategy(AppConfig.ACCESS_KEY_ID, AppConfig.SECRET_ACCESS_KEY)
        host = AppConfig.DEFAULT_ICP_HOST
        return ApiClient(host, strategy)

    click.echo("❌ 请设置环境变量 ARKCLAW_TOKEN 或 ACCESS_KEY_ID/SECRET_ACCESS_KEY", err=True)
    sys.exit(1)


def upload(args: dict) -> Matriel:
    args.setdefault("title", f"artclaw-material-{int(time.time())}")
    args.setdefault("owner_type", "user")

    client = _build_client()
    uploader = MaterialUploader(client)
    
    owner_id = args.get("owner_id") or uploader.iam.get_admin_user_id()
    file_path = args["file"]
    file_md5, file_crc32, file_size = HashUtils.file_hash(file_path)
    
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    file_ext = os.path.splitext(file_path)[1].lstrip(".")
    
    cat = args.get("category", "video")
    if cat == "video":
        cat = "image" if file_ext.lower() in AppConfig.IMAGE_EXTENSIONS else "video"

    state = uploader.muse.get_upload_state(file_md5, file_size, file_crc32, owner_id)
    state = uploader.stream_upload(file_path, file_md5, file_size, file_crc32, owner_id, state)
    
    media_id = uploader.muse.create_material(
        file_md5, file_size, file_name, file_ext, 
        state["SkipDataComplete"], owner_id, args["owner_type"], args["title"], cat
    )
    
    media_info = uploader.muse.poll_media_info(media_id, owner_id, args["owner_type"])
    return MediaFormatter.format(MediaFormatter.simplify(media_info))