import sys
import json
import time
import logging
import click
from collections import defaultdict

from .media import service as mediaService
from .base import Result
from .service import api_submit, api_query


def concat(input, group, ids) -> dict:
    material = defaultdict()
    if input:
        with open(input, "r") as f:
            material = json.load(f)

    if group:
        materials = mediaService.list_media(group)
        if ids:
            target_ids = {i.strip() for i in ids.split(",") if i.strip()}
            materials = [m for m in materials if m.get("id") in target_ids]
        if 10 < len(materials):
            error_res = {"code": "1416", "message": f"素材总数({len(materials)})超过了10个的限制，请减少素材数量后再试"}
            click.echo(json.dumps(error_res, ensure_ascii=False), err=True)
            sys.exit(1)

        material["user_images"] = [m for m in materials if m["type"] == "image"] # type: ignore
        material["user_videos"] = [m for m in materials if m["type"] == "video"] # type: ignore
    return material

@click.command()
@click.option("--input", type=str, help="素材分析结果JSON文件路径")
@click.option("--group", type=str, help="已上传的远程素材列表对应的分组ID")
@click.option("--ids", type=str, help="参与分析的素材ID列表，多个ID用逗号分隔")
@click.option("--output", required=True, type=str, help="输出结果所在的json文件路径")
def main(input, group, ids, output):
    """创意分析工具，参考[创意分析指南](references/创意分析指南.md)"""
    logging.info(f"[tool] >>> python3 {' '.join(sys.argv)}")

    material = json.dumps(concat(input, group, ids), ensure_ascii=False)
    submit_res = api_submit(13891330, material)
    click.echo(submit_res.model_dump_json())
    if submit_res.code != "0": exit(1)
    click.echo(f"提交任务成功，任务ID: {submit_res.message}")

    for _ in range(2 * 3):
        time.sleep(30)
        poll_res = api_query(submit_res.message)
        
        if poll_res.code == "1000":
            continue

        if poll_res.code != "0":
            click.echo(poll_res.model_dump_json(), err=True)
            exit(1)

        with open(output, "w") as f:
            result = json.loads(poll_res.message)
            result.pop("duration", None)
            result.pop("aspect_ratio", None)
            json.dump(result, f, ensure_ascii=False, indent=2)
        click.echo(Result(code="0", message=output).model_dump_json())
        click.echo(f"任务完成，结果已保存到 {output}")
        return

    click.echo(f"任务正在执行中，请通过任务ID:{submit_res.message}查询任务状态")

if __name__ == "__main__":
    main()