import json
import os
import sys
import time
import logging
import click
from abc import ABC, abstractmethod
from typing import Dict, Any, List
from pathlib import Path
import pandas as pd
from PIL import Image
import cv2
import math

from .base import Result
from .chunks import upload

__all__ = ["BaseValidator", "DefaultValidator", "MediaService", "service"]

class MediaConfig:
    """媒体相关配置与常量"""
    IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
    VIDEO_EXTENSIONS = {".mp4", ".avi", ".mov"}
    
    IMAGE_MAX_SIZE = 8 * 1024 * 1024
    VIDEO_MAX_SIZE = 50 * 1024 * 1024
    
    IMAGE_MIN_WIDTH = 300
    IMAGE_MIN_HEIGHT = 300
    IMAGE_MAX_PIXELS = 36_000_000
    
    CSV_COLUMNS = ["group", "channel", "account", "path", "id", "material", "timestamp"]
    STORAGE_BASE_DIR = "/tmp/openclaw/replicator/media"


class BaseValidator(ABC):
    """校验器基类 (策略模式接口)"""
    @abstractmethod
    def validate(self, file_path: str) -> Dict[str, Any]:
        pass


class ImageValidator(BaseValidator):
    """图片校验器 (具体策略)"""
    
    def validate(self, file_path: str) -> Dict[str, Any]:
        result = {"valid": False, "file_type": "image", "errors": [], "warnings": [], "info": {}}
        file_size = os.path.getsize(file_path)
        result["info"]["size"] = file_size
        if file_size > MediaConfig.IMAGE_MAX_SIZE:
            result["warnings"].append("图片单张大小建议≤8MB")
            return result
        try:
            with Image.open(file_path) as img:
                width, height = img.size
                result["info"]["width"] = width
                result["info"]["height"] = height
                
                total_pixels = width * height
                if width < MediaConfig.IMAGE_MIN_WIDTH or height < MediaConfig.IMAGE_MIN_HEIGHT:
                    result["errors"].append(f"图片分辨率不足，当前为 {width}x{height}，要求至少 300x300")
                if total_pixels > MediaConfig.IMAGE_MAX_PIXELS:
                    result["errors"].append(f"图片总像素过大，当前为 {total_pixels}，要求≤36,000,000")
                
                if not result["errors"]:
                    result['valid'] = True
                return result
        except Exception as e:
            result["errors"].append(f"无法读取图片文件: {e}")
            return result


class VideoValidator(BaseValidator):
    """视频校验器 (具体策略)"""
    
    def validate(self, file_path: str) -> Dict[str, Any]:
        result = {"valid": False, "file_type": "video", "errors": [], "warnings": [], "info": {}}
        file_size = os.path.getsize(file_path)
        result["info"]["size"] = file_size
        if file_size > MediaConfig.VIDEO_MAX_SIZE:
            result["errors"].append("视频文件大小超过 50MB")
            return result
            
        cap = cv2.VideoCapture(file_path)
        if not cap.isOpened():
            result["errors"].append(f"无法使用 cv2 打开视频文件: {file_path}")
            return result
        try:
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            duration = math.floor(frame_count / fps if fps > 0 else 0.0) + 1

            result["info"]["width"] = width
            result["info"]["height"] = height
            result["info"]["duration"] = duration
            
            result['valid'] = True
        except Exception as e:
            result["errors"].append(f"获取视频信息失败: {e}")
        finally:
            cap.release()
            
        return result


class ValidatorFactory:
    """校验器工厂类"""
    _validators: Dict[str, BaseValidator] = {}

    @classmethod
    def register(cls, extensions: set, validator: BaseValidator):
        for ext in extensions:
            cls._validators[ext] = validator

    @classmethod
    def get_validator(cls, ext: str) -> BaseValidator:
        return cls._validators.get(ext) # type: ignore

    @classmethod
    def validate(cls, file_path: str) -> Dict[str, Any]:
        """根据扩展名分发给具体策略进行校验"""
        result = {"valid": False, "file_type": None, "errors": [], "warnings": [], "info": {}}
        
        if not os.path.isfile(file_path):
            result["errors"].append("文件不存在")
            return result

        _, ext = os.path.splitext(file_path)
        ext = ext.lower()

        validator = cls.get_validator(ext)
        if validator:
            return validator.validate(file_path)

        result["errors"].append("不支持的文件格式，仅支持图片(jpg/jpeg/png)或视频(mp4/avi/mov)")
        return result

# 注册校验器策略
ValidatorFactory.register(MediaConfig.IMAGE_EXTENSIONS, ImageValidator())
ValidatorFactory.register(MediaConfig.VIDEO_EXTENSIONS, VideoValidator())

class DefaultValidator(BaseValidator):
    """默认校验器：根据文件扩展名自动分发给对应的图片或视频校验策略"""
    def validate(self, file_path: str) -> Dict[str, Any]:
        return ValidatorFactory.validate(file_path)


class MediaRepository:
    """仓储层：处理底层 CSV 数据的读写"""
    
    def __init__(self, base_dir: str = MediaConfig.STORAGE_BASE_DIR):
        self.base_dir = Path(base_dir)

    def _get_path(self, group: str) -> Path:
        return self.base_dir / f"{group}.csv"

    def load(self, group: str) -> pd.DataFrame:
        path = self._get_path(group)
        if not path.exists():
            return pd.DataFrame(columns=MediaConfig.CSV_COLUMNS)
        return pd.read_csv(path, header=None, names=MediaConfig.CSV_COLUMNS)

    def save(self, group: str, df: pd.DataFrame):
        path = self._get_path(group)
        os.makedirs(path.parent, exist_ok=True)
        df.to_csv(path, index=False, header=False)

    def clear(self, group: str):
        path = self._get_path(group)
        if path.exists():
            os.remove(path)


class MediaService:
    """业务服务层：协调校验、提取、上传与存储"""
    
    def __init__(self, repository: MediaRepository):
        self.repository = repository

    def add_media(self, file: str, group: str, metadata: dict, validator: BaseValidator) -> Any:
        validation_result = validator.validate(file)
            
        if not validation_result['valid']:
            return validation_result

        # 上传文件到远程服务器
        matriel = upload({"file": file})

        # 补全缺失的媒体信息并添加info中的所有kv对
        info = validation_result.get("info", {})
        for k, v in info.items():
            if hasattr(matriel, k):
                setattr(matriel, k, v)
        
        # 构造存储记录
        row = {
            'group': group,
            'channel': metadata.get('channel', ''),
            'account': metadata.get('chat_id', ''),
            'path': file,
            'id': matriel.id,
            'material': matriel.model_dump_json(),
            'timestamp': str(time.time())
        }

        # 持久化到仓储
        df = self.repository.load(group)
        df.loc[len(df)] = row
        self.repository.save(group, df)
        
        return matriel

    def list_media(self, group: str) -> List[Dict]:
        df = self.repository.load(group)
        if df.empty:
            return []
        return df["material"].map(lambda x: json.loads(x)).to_list() # type: ignore

    def remove_media(self, media_id: str, group: str):
        df = self.repository.load(group)
        df.drop(df[df["id"].eq(media_id)].index, inplace=True)
        self.repository.save(group, df)

    def clear_media(self, group: str):
        self.repository.clear(group)


# --- 接口层 (CLI) ---

repository = MediaRepository()
service = MediaService(repository)

@click.group()
def main():
    """抖音营销素材上传工具"""
    logging.info(f"[tool] >>> python3 {' '.join(sys.argv)}")


@main.command()
@click.argument('file')
@click.option('--group', required=True, type=str, help='素材所属的素材组，全局唯一')
@click.option('--metadata', required=True, type=str, help='当前消息的完整未修改元信息，json格式')
def add(file, group, metadata):
    """上传抖音营销素材到远程服务器，返还上传后的素材ID"""
    meta_dict = json.loads(metadata)
    result = service.add_media(file, group, meta_dict, DefaultValidator())
    click.echo(result)


@main.command()
@click.option('--group', required=True, type=str, help='素材所属的素材组，全局唯一')
def list(group):
    """列出当前分组中所有已上传的抖音营销素材"""
    click.echo(service.list_media(group))


@main.command()
@click.option('--group', required=True, type=str, help='素材所属的素材组，全局唯一')
def clear(group):
    """清空当前分组中所有已上传的抖音营销素材"""
    service.clear_media(group)


@main.command()
@click.option('--id', required=True, type=str, help='素材ID')
@click.option('--group', required=True, type=str, help='素材所属的素材组，全局唯一')
def remove(id, group):
    """移除指定的素材"""
    service.remove_media(id, group)


if __name__ == "__main__":
    main()